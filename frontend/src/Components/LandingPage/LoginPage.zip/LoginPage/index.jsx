import * as React from "react";
import "./login.css";
import axios from "axios";
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";

function LoginPage() {
  const nav = useNavigate();

  // State variables to hold the input values
  const [values, setValues] = useState({
    email: "",
    password: "",
  });

  // Function to handle changes in input field
  const handleInput = (event) => {
    setValues(prev => ({
      ...prev,
      [event.target.name]: [event.target.value]
    }));
  };
  axios.defaults.withCredentials = true;
  // Function to handle form submission
  const handleSubmit = (event) => {
    event.preventDefault();
      axios.post('http://localhost:8081/login',values)
      .then(res =>{
        console.log(values)
        if(res.data === "Admin"){
          localStorage.setItem("user","kainat");
          console.log("admin")
          nav("/home");
        }
        else if(res.data === "HOD"){
          console.log("hod")
          nav("/HODHomePage")
        }
        else if(res.data === "Dean"){
          console.log("dean")
          nav("/DeanHomePage")
        }
        else if(res.data === "Examination"){
          console.log("examination")
          nav("/ControllerOfExaminationHomePage")
        }
        else if(res.data === "Teacher"){
          console.log("teacher")
          nav("/teacher")
        }
        else if(res.data ==="Failed"){
          alert("Invalid Login")
        }
      })
        
  };
   
  


  return (
    <div id="mainLoginDiv">
      <div id="newbg">
     <div id="formbg">
     <div id="leftSection">
      
        <h2>Login Form</h2>
        <form>
       
          <div>
            <label for="email">Email</label>
            <input type="email" id="email" name="email" placeholder="Enter your email"/>
          </div>
          <div>
            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="Enter your password"/>
          </div>
          <button type="submit">Login</button>
        </form>
      </div>
      <div id="rightSection">
        <img src={require("./CapwithBooks.png")} alt="Some Image"/>
      </div>
     </div>
     </div>
    </div>
  );
}



export default LoginPage;