// app/GeminiAPI/index.js
import axios from 'axios';

// const API_URL = 'https://api.openai.com/v1/engines/gpt-3.5/completions'; // URL for GPT-3.5 Turbo model
const API_KEY = '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'; // Replace with your actual OpenAI API key
// const API_URL = 'https://api.openai.com/v1/completions'; // URL for GPT-3.5 model

const API_URL = 'https://api.openai.com/v1/completions'; // URL for earlier models

export const getChatGPTResponse = async (messages) => {
  try {
    const response = await axios.post(
      API_URL,
      {
        model: "gpt2", // Use GPT-3.5-turbo model
        messages: [
          { role: "system", content: "You are a helpful assistant." },
          ...messages // Array of user and assistant messages
        ],
        max_tokens: 150, // Optional: limit the response length
        temperature: 0.7, // Optional: controls randomness of the generated text
        top_p: 1.0, // Optional: diversity of responses
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${API_KEY}`,
        },
      }
    );

    return response.data.choices[0].message.content.trim();
  } catch (error) {
    console.error('Error:', error.response ? error.response.data : error.message);
    return "I'm sorry, something went wrong. Please try again later.";
  }
};