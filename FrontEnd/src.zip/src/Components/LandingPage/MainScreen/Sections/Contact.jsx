import React from "react";
import styled from "styled-components";
// Assets

import ContactImg1 from "./c1.jpeg";
import ContactImg2 from "./c2.jpeg";
import ContactImg3 from "./c3.jpeg";

// import ContactImg1 from "./c3.jpeg";
// import ContactImg2 from "./c1.jfif";
// import ContactImg3 from "./c2.jpeg";

// import ContactImg1 from "../../../../assets/img/contact-1.png";
// import ContactImg2 from "../../../../assets/img/contact-2.png";
// import ContactImg3 from "../../../../assets/img/contact-3.png";

export default function Contact() {
  return (
    <Wrapper id="contact">
      <div className="lightBg">
        <div className="container">
          <HeaderInfo>
            <h1 className="font40 extraBold" style={{color: "#00304B",}}>Let's get in touch</h1>
            <h2 className="font13" style={{ marginTop:"20px", fontSize: "19px", color: "#00304B", textAlign: "justify" }}>
              We’re here to assist you!
              </h2>
              <h2 className="font13" style={{ marginTop:"20px",fontSize: "18px", color: "#00304B", textAlign: "justify" }}>
              Whether you have questions, need support, or want to learn more about our services,
              <br />
              feel free to reach out. Fill in your details, and our team will get back to you as soon
              <br />
              as possible. We're excited to help you accelerate your academic journey!
            </h2>

            {/* <p className="font13">
              Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut
              <br />
              labore et dolore magna aliquyam erat, sed diam voluptua.
            </p> */}
          </HeaderInfo>
          <div className="row" style={{ paddingBottom: "30px" }}>
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-6">
              <Form>
                <label className="font13" style={{ marginTop:"-60px", fontSize: "20px", color: "#00304B" }}>First Name:</label>
                <input type="text" id="fname" name="fname" className="font20 semiBold"style={{fontSize: "18px"}} />

                <label className="font13" style={{ fontSize: "20px", color: "#00304B" }}>Email:</label>
                <input type="text" id="email" name="email" className="font20 semiBold" style={{fontSize: "18px"}} />

                <label className="font13" style={{ fontSize: "20px", color: "#00304B" }}>Subject:</label>
                <input type="text" id="subject" name="subject" className="font20 semiBold" style={{fontSize: "18px"}} />

                <textarea rows="4" cols="50" type="text" id="message" name="message" className="font20 semiBold" style={{fontSize: "18px"}} />
              </Form>
              <SumbitWrapper className="flex">
                <ButtonInput type="submit" value="Send Message" className="pointer animate radius8 semiBold flexCenter"
                  style={{
                    maxWidth: "180px",
                    color: "#00304B",
                    background: "linear-gradient(to right, #93C098, #8CE0DB)",
                    fontSize: "20px",
                    border:"none",
                    
                  }} />
              </SumbitWrapper>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-6 flex">
              <div style={{ width: "50%" }} className="flexNullCenter flexColumn">
                <ContactImgBox>
                  <img src={ContactImg1} style={{ width: "260px", height: "240px" ,marginLeft:"-60px", marginTop: "-160px"}} alt="office" className="radius6" />
                </ContactImgBox>
                <ContactImgBox>
                  <img src={ContactImg2} style={{ width: "260px", height: "260px",marginLeft:"-60px", marginTop: "30px" }} alt="office" className="radius6" />
                </ContactImgBox>
              </div>
              <div style={{ width: "50%" }}>
                <div style={{ marginTop: "30px" }}>
                  <img src={ContactImg3} style={{ width: "350px", height: "300px", marginLeft:"20px" }} alt="office" className="radius6" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Wrapper>
  );
}

const Wrapper = styled.section`
  width: 100%;
`;
const HeaderInfo = styled.div`
  padding: 70px 0 30px 0;
  @media (max-width: 860px) {
    text-align: center;
  }
`;
const Form = styled.form`
  padding: 70px 0 30px 0;
  input,
  textarea {
    width: 100%;
    background-color: transparent;
    border: 0px;
    outline: none;
    box-shadow: none;
    border-bottom: 1px solid #707070;
    height: 30px;
    margin-bottom: 30px;
  }
  textarea {
    min-height: 100px;
  }
  @media (max-width: 860px) {
    padding: 30px 0;
  }
`;
const ButtonInput = styled.input`
  border: 1px solid #7620ff;
  background-color: #7620ff;
  width: 100%;
  padding: 15px;
  outline: none;
  color: #fff;
  :hover {
    background-color: #580cd2;
    border: 1px solid #7620ff;
    color: #fff;
  }
  @media (max-width: 991px) {
    margin: 0 auto;
  }
`;
const ContactImgBox = styled.div`
  max-width: 180px; 
  align-self: flex-end; 
  margin: 10px 30px 10px 0;
`;
const SumbitWrapper = styled.div`
  @media (max-width: 991px) {
    width: 100%;
    margin-bottom: 50px;
  }
`;









