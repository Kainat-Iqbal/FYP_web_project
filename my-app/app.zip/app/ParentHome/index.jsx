import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ParentHome = () => {
  return (
    <View>
      <Text>ParentHome</Text>
    </View>
  )
}

export default ParentHome

const styles = StyleSheet.create({})