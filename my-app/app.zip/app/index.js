// app/index.js
import { Redirect } from 'expo-router';

const Index = () => {
  return <Redirect href="/Login" />; // Redirect to the login screen
};

export default Index;
